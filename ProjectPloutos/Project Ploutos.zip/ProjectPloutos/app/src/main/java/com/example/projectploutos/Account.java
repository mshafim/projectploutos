package com.example.projectploutos;

public class Account {
    private String accountName;
    private String balance;

    public Account(String accountName, double balance) {
        this.accountName = accountName;
        this.balance = Double.toString(balance);
    }

    public String getAccountName() {
        return accountName;
    }

    public String getBalance(){
        return balance;
    }
}
